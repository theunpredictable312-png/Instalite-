import 'package:flutter/material.dart';

class NewPostScreen extends StatelessWidget {
  const NewPostScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('New Post (enable after Firebase Storage)'));
  }
}
