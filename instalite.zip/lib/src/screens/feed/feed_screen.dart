import 'package:flutter/material.dart';
import '../../widgets/post_card.dart';
import '../../services/mock_service.dart';

class FeedScreen extends StatelessWidget {
  const FeedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final posts = MockService.feed(); // replace with Firestore stream later
    return ListView.builder(
      itemCount: posts.length,
      itemBuilder: (_, i) => PostCard(post: posts[i]),
    );
  }
}
