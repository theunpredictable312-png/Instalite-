class Post {
  final String id;
  final String username;
  final String userPhoto;
  final String imageUrl;
  final String caption;
  final DateTime createdAt;
  final List<String> likes;

  Post({
    required this.id,
    required this.username,
    required this.userPhoto,
    required this.imageUrl,
    required this.caption,
    required this.createdAt,
    required this.likes,
  });
}
