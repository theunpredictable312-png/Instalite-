import 'dart:math';
import '../models/post.dart';

class MockService {
  static final _rnd = Random();

  static List<Post> feed() {
    final now = DateTime.now();
    return List.generate(8, (i) {
      return Post(
        id: '$i',
        username: 'user_$i',
        userPhoto: '',
        imageUrl: 'https://picsum.photos/seed/${i+1}/800/800',
        caption: 'Caption #$i — Hello InstaLite!',
        createdAt: now.subtract(Duration(hours: i * 3)),
        likes: List.filled(_rnd.nextInt(230), 'u'),
      );
    });
  }
}
