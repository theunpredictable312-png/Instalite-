import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/session_provider.dart';
import 'screens/home/home_screen.dart';
import 'screens/auth/sign_in_screen.dart';

class InstaLite extends StatelessWidget {
  const InstaLite({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [ChangeNotifierProvider(create: (_) => SessionProvider())],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'InstaLite',
        theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: Colors.black)),
        home: const _Root(),
      ),
    );
  }
}

class _Root extends StatelessWidget {
  const _Root({super.key});

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionProvider>();
    if (!session.isReady) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return session.user == null ? const SignInScreen() : const HomeScreen();
  }
}
