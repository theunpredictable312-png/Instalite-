import 'package:flutter/material.dart';

class AppUser {
  final String uid;
  final String email;
  final String username;
  AppUser({required this.uid, required this.email, required this.username});
}

class SessionProvider extends ChangeNotifier {
  AppUser? user;
  bool isReady = true; // set true for mock; tie to Firebase auth stream later

  void mockSignIn(String email) {
    user = AppUser(uid: 'mock', email: email, username: email.split('@').first);
    notifyListeners();
  }

  void signOut() {
    user = null;
    notifyListeners();
  }
}
