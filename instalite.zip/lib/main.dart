import 'package:flutter/material.dart';
import 'src/app.dart';

void main() {
  // Firebase.initializeApp() can be added when you add google-services.json
  runApp(const InstaLite());
}
